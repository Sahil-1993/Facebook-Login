//
//  ViewController.swift
//  FacebookLogInExample
//
//  Created by Sahil Arora on 2020-11-22.
//  Copyright © 2020 Sahil Arora. All rights reserved.
//

import UIKit
import FBSDKCoreKit
import FBSDKLoginKit


class ViewController: UIViewController,LoginButtonDelegate {
   
    var loginButton = FBLoginButton()
   
    private var label:UILabel = {
        let lbl = UILabel()
        lbl.text = ""
        lbl.isHidden = true
        lbl.textAlignment = .center
        lbl.textColor = UIColor.link
        lbl.font = UIFont(name: "Arial", size: 20.0)
        return lbl
    }()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        let token = AccessToken.current
        label.frame = CGRect(x: 10, y: ((self.view.frame.size.height - 60)/2), width: (self.view.frame.size.width - 20), height: 60)
        view.addSubview(label)
        if token?.isExpired ?? true
        {
            
                 loginButton.center = view.center
                 loginButton.delegate = self
                 loginButton.permissions = ["public_profile", "email"]
                 view.addSubview(loginButton)
            
        }
            
        
    else{
            label.isHidden = false
            label.text = "You are already logged in"
    }
}
     func loginButton(_ loginButton: FBLoginButton, didCompleteWith result: LoginManagerLoginResult?, error: Error?) {
        let token = result?.token?.tokenString
        let request = FBSDKLoginKit.GraphRequest(graphPath: "me", parameters: ["fields":"email,name"], tokenString: token, version: nil, httpMethod: .get)
        request.start(completionHandler: { connection, result, error in
            
    
            if result != nil
            {
                DispatchQueue.main.async {
                    loginButton.isHidden = true
                    self.label.isHidden = false
                    self.label.text = (result as! NSDictionary).value(forKey: "name")as? String
                   
                }
            }
         else
            {
                print(error.debugDescription)
            }
            
        })
       
      
}

    func loginButtonDidLogOut(_ loginButton: FBLoginButton) {
           
       }
}
